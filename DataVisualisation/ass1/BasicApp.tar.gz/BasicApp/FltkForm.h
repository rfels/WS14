/*
 * FltkForm.h
 */

#ifndef FltkForm_h_
#define FltkForm_h_
//#include <GL/gl.h>

#include <FL/Fl.H>
#include <Fl/Fl_Gl_Window.H>
#include "FastTrackball.h"

#include <cstdlib>
#include <iostream>

class FltkForm : public Fl_Gl_Window
{
 protected:
  void (*userDrawFunc)();

 public:
  FltkForm(int x, int y, int w, int h, const char *l = 0)
    : Fl_Gl_Window(x, y, w, h, l),
    xShift(0.0), yShift(0.0),size(1.0),
    enableTranslation(1), enableZoom(1), enableRotation(1) {

      this->mode( FL_RGB8 | FL_ALPHA |
		  FL_DOUBLE | FL_DEPTH ) ;
      end() ;
    }
  ~FltkForm() { }

  double size;

  Trackball trackball ;
  float xShift, yShift ;
  int oldPosX, oldPosY, newPosX, newPosY ;

  int enableTranslation, enableZoom, enableRotation ;

  void draw(void);
  void getVersions(void) ;
  void resize(int, int, int, int);
  void reset(void);
  void setInitSize() ;

  int handle(int);
  int handleMouse(int, int, int, int);
  int handleKey(int, int);


  // Manipulating lights

  void enableLights( void ) ;
  void disableLights( void ) ;

  // Drawing function

  void drawFunc(void(*fp)())
  { userDrawFunc = fp; }
};

#endif

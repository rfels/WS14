#ifndef RenderMethods_h_
#define RenderMethods_h_

#include "GridPoint.h"
#include "Color.h"
#include <GL/gl.h>


void begin_aa_line( void ) ;
void end_aa_line( void ) ;

//================================================= //

void plot_points( double xx, double yy, double zz,
		  double rr, double gg, double bb,
		  float pointsize = 1.0 ) ;
void plot_points( std :: vector<GridPoint> g, Color c,
		 int pointsize = 1 ) ;
void plot_points( GridPoint g, Color c,
		 float pointsize = 1.0 ) ;
//void highlight_point( GridPoint g, float pointsize )
//{  plotPoints(g, Color(1,1,0), pointsize) ; }

// ================================================= //

void draw_line( GridPoint g1, GridPoint g2, Color c ) ;

template<unsigned int nsize>
void drawLineLoop(GridPoint g[nsize], Color c)
{
  glColor3f(c.red(), c.green(), c.blue()) ;
  glBegin(GL_LINE_LOOP) ;
  for (int i = 0 ; i < nsize ; i++)
    glVertex3dv(g[i].positionVector) ;
  glEnd() ;
}

// ================================================= //

void draw_triangle( GridPoint g1, GridPoint g2, GridPoint g3, Color c ) ;
void draw_triangle( GridPoint g[3], Color c ) ;
void draw_triangle( GridPoint g[3], GridPoint n, Color c ) ;
void draw_triangle_line( GridPoint g[3], Color c ) ;
void draw_triangle_line( GridPoint g0, GridPoint g1, GridPoint g2, Color c ) ;

// ================================================= //
void draw_bounding_box(double minx, double miny, double minz,
		       double maxx, double maxy, double maxz) ;
void draw_axes(void) ;
#endif

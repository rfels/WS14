#include "FltkView.h"
#include <FL/gl.h>
#include <cmath>
//#include "RenderMethods.h"

FltkView *fv ;
double g_minx = -10 ; //1e4 ;
double g_miny = -10 ; //1e4 ;
double g_minz = -10 ; //1e4 ;
double g_maxx = 10 ; //-1e4 ;
double g_maxy = 10 ; //-1e4 ;
double g_maxz = 10 ; //-1e4 ;

void main_display(void) {
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT) ;
  glClearColor(1,1,1,1) ;
  /*draw_axes() ;
    draw_bounding_box(g_minx, g_miny, g_minz,
      g_maxx, g_maxy, g_maxz) ;
  */
        
  GLfloat x,y,z, r = 4.5, c = 0.5 ;
  glLineWidth(8.0) ;
  glBegin(GL_LINE_STRIP); 
  glColor3f(0.0, 1.0, 0.0);           
  for(GLfloat theta = 0; theta <= 22.5; theta+=0.1) { 
    x = r*(cos(theta));
    y = r*(sin(theta));
    z = c*theta; 
    glVertex3f(x,y,z);
  }
  glEnd();
  glLineWidth(1.) ;
    
}

int main(int argc, char **argv)
{
  fv = new FltkView( 0, 0, 600, 600, "Basic App" ) ;
  
  fv -> form-> drawFunc(main_display);
  fv -> show();   

  return Fl :: run() ;
}

/*
 * FltkForm.C
 */

#include "FltkForm.h"
#include <FL/gl.h>

GLdouble x_ang, y_ang ;
int enable_fullscreen = 0 ;

void FltkForm :: draw( void ) {
  if (!valid()) {

      valid( 1 );
      glClearColor( 0.85, 0.85, 0.85, 1 );    
      glEnable( GL_DEPTH_TEST );
      
      getVersions() ;

      glLoadIdentity( ) ;
      glViewport( 0, 0, w(), h() );

      // Orthographic projection

      glMatrixMode( GL_PROJECTION ) ;
      glLoadIdentity() ;

      setInitSize() ;

      glMatrixMode( GL_MODELVIEW ) ;
      glLoadIdentity() ;
    }

  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT ); 
  glPushMatrix();
  
  static float rotation_transform[4][4] ;

  // TODO Fix trackball.
   trackball.rotationMatrix( rotation_transform ) ;

   glScalef( float( size ), float( size ), float( size ) );
   glTranslatef( xShift/size, -yShift/size, 0 );
   glMultMatrixf( &rotation_transform[0][0] ) ;
   
   userDrawFunc();  
   glPopMatrix();  
}

void FltkForm :: getVersions(void) {
  const char* verstr = 
    (const char*)glGetString(GL_VERSION) ;

  if (verstr) 
    std :: cerr << "GL_VERSION : " << verstr 
		<< std :: endl ;
  else
    std :: cerr << "Error in determining OpenGL version"
		<< std :: endl ;

  return ;
}

void FltkForm :: resize(int X, int Y, int W, int H) {
  // Let FLTK resize the widget
  Fl_Gl_Window::resize(X, Y, W, H);
  
  if(!valid()) {
    glViewport(0, 0, W, H);
    glEnable(GL_DEPTH_TEST);
  }
}

void FltkForm :: reset(void) {
  xShift = 0.0 ;
  yShift = 0.0 ;
  size = 10.0;

  oldPosX = oldPosY = newPosX = newPosY = 0;
  return;
}

void FltkForm :: setInitSize(void) {
  glOrtho(-20, 20, -20, 20, -100, 100) ;
}

// Routines for mouse/keyboard
int FltkForm :: handle(int event) {
  switch(event) {

    case FL_ENTER:
      Fl::focus() ;
      return 1 ;

    case FL_MOVE:
    case FL_LEAVE:
      //this->redraw();
      return 1;

    case FL_PUSH:
    case FL_RELEASE:
    case FL_DRAG:
      return handleMouse(event, Fl::event_button(), 
			  Fl::event_x(),Fl::event_y());

    case FL_SHORTCUT:
    case FL_KEYBOARD:
      Fl::focus() ;
      return handleKey(event, Fl::event_key());
	
    default:
      return Fl_Window::handle(event);
    }
  return 0;
}


int FltkForm :: handleKey(int event, int key) {
  switch(key) {
      /*    case 'm':
    case 'M':
      enable_mesh = 1-enable_mesh ;
      this->redraw() ;
      return 1 ;

    case 'i':
    case 'I':
      enable_intersections = 1-enable_intersections ;
      this->redraw() ;
      return 1 ;*/

    case 'r':
    case 'R':
      enableRotation = 1-enableRotation ;
      this->redraw() ;
      return 1 ;

    case '=':
      if (enableZoom == 1) {
	size = (size < 50.0) ? size+0.2 : 50. ;
	this->redraw();
      }
      
      return 1;

    case '-':
      if (enableZoom == 1) {
	size = (size > 1.0) ? size-0.2 : 1. ;
	this->redraw();
      }
      
      return 1;

  case FL_Escape:
    exit(0) ;

  default:
    return 0;
  }
}

int FltkForm :: handleMouse(int event, int button, 
			    int xx, int yy) {
  int ret = 0;
  switch(button) {

    // Translation 
  case 3:
    ret = 1;
    if (event == FL_PUSH) {

      oldPosX = newPosX = xx ;
      oldPosY = newPosY = yy ;
    }
    else if ((event == FL_DRAG) || (event == FL_RELEASE)) {
      
      newPosX = xx ;
      newPosY = yy ;
      if (enableTranslation == 1) {

	// ortho_width and ortho_height come from the orthographic
	// projection dimensions. If they should change, the
	// developer should update these two variables.
	const float ortho_width = 20 ;
	//const float ortho_height = 20 ;
	
	xShift += ortho_width*(newPosX - oldPosX)/double(w()) ;
	yShift += ortho_width*(newPosY - oldPosY)/double(h()) ;
      }
      oldPosX = xx ;
      oldPosY = yy ;
      this->redraw();
    }
    break;
    
    // Rotation
  case 1:
    if (!enableRotation) break ;
    ret = 1 ;
    if ( event == FL_PUSH ) {

      // Get the initial mouse position
      // and make sure the trackball stops.
      x_ang = xx ;
      y_ang = yy ;
      trackball.rotate( 0,0,0,0 ) ;
    }
    else if (( event == FL_DRAG ) ) {

      if ( enableRotation == 1 )
	trackball.rotate((2.0 * x_ang - w()) / float(w()),
			 (h() - 2.0 * y_ang) / float(h()),
			 (2.0 * xx - w()) / float(w()),
			 (h() - 2.0 * yy) / float(h()));
      x_ang = xx ; y_ang = yy ;
      this->redraw();
    }
    break ;
    
  default:
    ret = 0;
    break;
  }
  return ret;
}

GLfloat mat_specular[] = { 1, 1, 1, 1 } ; 
GLfloat mat_shininess[] = { 10.0 } ;
GLfloat light_position1[] = { 10.0, 10.0, 10.0, 0 } ;
GLfloat white_light[] = { 0.7, 0.7, 0.7, 1 } ;
GLfloat ambient_light[] = { 0.8, 0.8, 0.8, 1 } ;

void FltkForm :: enableLights( void ) { 
  glMaterialfv(GL_FRONT, GL_SPECULAR, ambient_light);
  glMaterialfv( GL_FRONT, GL_SHININESS, mat_shininess ) ;
  glMaterialfv( GL_FRONT, GL_DIFFUSE, white_light ) ;
  glMaterialfv( GL_FRONT, GL_AMBIENT, ambient_light ) ;
  glLightfv( GL_LIGHT0, GL_POSITION, light_position1 ) ;
   
  glLightfv( GL_LIGHT0, GL_DIFFUSE, white_light ) ;
  glLightfv( GL_LIGHT0, GL_SPECULAR, white_light ) ;
  glLightfv( GL_LIGHT0, GL_AMBIENT, white_light ) ;
 
  glEnable( GL_LIGHTING ) ;
  glEnable( GL_LIGHT0 ) ;
 
  glColorMaterial( GL_FRONT, GL_DIFFUSE ) ;
  glEnable( GL_COLOR_MATERIAL ) ;
}

void FltkForm :: disableLights( void ) {
  glDisable( GL_LIGHTING ) ;
  glDisable( GL_LIGHT0 ) ; 
  glDisable( GL_COLOR_MATERIAL ) ;
}

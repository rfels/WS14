#include "RenderMethods.h" 

void begin_aa_line( void ) {
  glLineWidth (1);
  glDisable(GL_DEPTH_TEST) ;
  glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA) ; 
  //( GL_SRC_ALPHA_SATURATE, GL_ONE );
  glEnable(GL_BLEND);
  glEnable(GL_LINE_SMOOTH) ;
  glPushAttrib(GL_LINE_BIT);
  glLineStipple(3, 0xAAAA);
}

void end_aa_line( void ) {
  glPopAttrib() ;
  glDisable(GL_BLEND) ;
  glDisable(GL_LINE_SMOOTH) ;
  glEnable(GL_DEPTH_TEST) ;
}

// ================================================= //

void plot_points( double xx, double yy, double zz,
		  double rr, double gg, double bb,
		  int pointsize ) {
  glPointSize(pointsize) ;
  glColor3f(rr, gg, bb) ;
  glBegin(GL_POINTS) ;
  glVertex3d(xx, yy, zz) ;
  glEnd() ;
}

void plot_points( std :: vector<GridPoint> g, 
		  Color c, int pointsize ) {
  glPointSize(pointsize) ;
  glColor3f(c.red(), c.green(), c.blue()) ;
  glBegin(GL_POINTS) ;
  for (int i = 0 ; i < g.size() ; i++)
    glVertex3dv(g[i].positionVector) ;
  glEnd() ;
}

void plot_points( GridPoint g, Color c, int pointsize ) {
  glPointSize(pointsize) ;
  glColor3f(c.red(), c.green(), c.blue()) ;
  glBegin(GL_POINTS) ;
  glVertex3dv(g.positionVector) ;
  glEnd() ;
}

// ================================================= //


void draw_line( GridPoint g1, GridPoint g2, Color c ) {
  glColor3f(c.red(), c.green(), c.blue()) ;
  glBegin(GL_LINES) ;
  glVertex3dv(g1.positionVector) ;
  glVertex3dv(g2.positionVector) ;
  glEnd() ;
}


// ================================================= //

void draw_triangle( GridPoint g1, GridPoint g2,
		    GridPoint g3, Color c ) {
  if (c.alpha() != 1.0)
    {
      glEnable(GL_BLEND) ; glDisable(GL_DEPTH_TEST) ;
      glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA) ;
      glColor4f(c.red(), c.green(), c.blue(), c.alpha()) ;
    }
  else glColor3f(c.red(), c.green(), c.blue()) ;

  glBegin(GL_TRIANGLES) ;
  glVertex3dv(g1.positionVector) ;
  glVertex3dv(g2.positionVector) ;
  glVertex3dv(g3.positionVector) ;
  glEnd() ;
  
  if (c.alpha() != 1.0)
    { glDisable(GL_BLEND) ; glEnable(GL_DEPTH_TEST) ; }
}

void draw_triangle( GridPoint g[3], Color c ) {
  draw_triangle(g[0],g[1],g[2],c) ; 
}

void draw_triangle( GridPoint g[3], GridPoint n, Color c ) {
  GLfloat color_light[] = { c.red(), c.green(), 
			    c.blue(), c.alpha() } ;
  GLfloat white_light_dp[] = {0.8,0.8,0.8,1} ;
  GLfloat grey_light_dp[] = {0.3,0.3,0.3,1,0.8,0.8,0.8,1} ;
  GLfloat mat_shininess_dp[] = {20.0} ;

  glMaterialfv( GL_FRONT_AND_BACK, GL_SHININESS, 
		mat_shininess_dp ) ;
  glMaterialfv( GL_FRONT_AND_BACK, GL_DIFFUSE, 
		&grey_light_dp[0] ) ;
  glMaterialfv( GL_FRONT_AND_BACK, GL_SPECULAR, 
		&grey_light_dp[4]) ; //white_light_dp ) ;
  glMaterialfv( GL_FRONT_AND_BACK, GL_AMBIENT, 
		color_light ) ;
  
  glEnable(GL_NORMALIZE) ;
  glColor3f(c.red(), c.green(), c.blue()) ;
  glBegin(GL_TRIANGLES) ;
  glNormal3dv(n.positionVector) ;
  glVertex3dv(g[0].positionVector) ;
  glVertex3dv(g[1].positionVector) ;
  glVertex3dv(g[2].positionVector) ;
  glEnd() ;
}

void draw_triangle_line( GridPoint g[3], Color c ) {
  glColor3f(c.red(), c.green(), c.blue()) ;
  begin_aa_line() ;
  glBegin(GL_LINE_LOOP) ;
  glVertex3dv(g[0].positionVector) ;
  glVertex3dv(g[1].positionVector) ;
  glVertex3dv(g[2].positionVector) ;
  glEnd() ;
  end_aa_line() ;
}

void draw_triangle_line( GridPoint g0, GridPoint g1,
			 GridPoint g2, Color c ) {
  glColor3f(c.red(), c.green(), c.blue()) ;
  //begin_aa_line() ;
  glLineStipple(3, 0x3F07 ); 
  glEnable(GL_LINE_STIPPLE) ;
  glBegin(GL_LINE_LOOP) ;
  glVertex3dv(g0.positionVector) ;
  glVertex3dv(g1.positionVector) ;
  glVertex3dv(g2.positionVector) ;
  glEnd() ;
  glDisable(GL_LINE_STIPPLE) ;
  //end_aa_line() ;
}

//================================================//

void draw_bounding_box(double minx, double miny, double minz,
		       double maxx, double maxy, double maxz) {
  glColor3f(0,0,0) ;
  begin_aa_line() ;
  glBegin(GL_LINE_LOOP) ;
  glVertex3f(minx, miny, minz) ;
  glVertex3f(minx, maxy, minz) ;
  glVertex3f(maxx, maxy, minz) ;
  glVertex3f(maxx, miny, minz) ;
  glEnd() ;
  glBegin(GL_LINE_LOOP) ;
  glVertex3f(minx, miny, maxz) ;
  glVertex3f(minx, maxy, maxz) ;
  glVertex3f(maxx, maxy, maxz) ;
  glVertex3f(maxx, miny, maxz) ;
  glEnd() ;

  glBegin(GL_LINES) ;
  glVertex3f(minx, miny, minz) ;
  glVertex3f(minx, miny, maxz) ;

  glVertex3f(minx, maxy, minz) ;
  glVertex3f(minx, maxy, maxz) ;

  glVertex3f(maxx, maxy, minz) ;
  glVertex3f(maxx, maxy, maxz) ;

  glVertex3f(maxx, miny, minz) ;
  glVertex3f(maxx, miny, maxz) ;
  glEnd() ;

  end_aa_line() ;
}

void draw_axes(void) {
#ifdef TEST
  float val = 1.0 ; 
#else
  float val = 100. ;
#endif

  glBegin(GL_LINES) ;
  glColor3f(1,0,0) ;
  glVertex3f(val,0.,0.) ;
  glVertex3f(0.,0.,0.) ;
  glColor3f(0,1,0) ;
  glVertex3f(0,val,0) ;
  glVertex3f(0,0,0) ;
  glColor3f(0,0,1) ;
  glVertex3f(0,0,val) ;
  glVertex3f(0,0,0) ;
  glEnd() ;
}

//

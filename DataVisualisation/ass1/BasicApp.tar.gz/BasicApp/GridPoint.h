#ifndef GridPoint_H_
#define GridPoint_H_

#include <iostream>
#include <vector>
#include <cmath>

/*
 * GridPoint consists of positionVector which is the vector
 * of x, y, z coordinates of a point
 */

class GridPoint {
  friend GridPoint operator+( const GridPoint &g1,
			      const GridPoint &g2 ) ;
  friend GridPoint operator-( const GridPoint &g1,
			      const GridPoint &g2 ) ;
  friend GridPoint operator*( const GridPoint &g1,
			      const double &g2 ) ;
  friend GridPoint operator*( const double &g2,
			      const GridPoint &g1 ) ;
  friend GridPoint operator/( const GridPoint &g1,
			      const double &g2 ) ;

  friend int operator== (const GridPoint &g1,
			 const GridPoint &g2 ) ;
  friend int operator!= (const GridPoint &g1,
			 const GridPoint &g2 ) ;
  friend GridPoint average( const std :: vector<GridPoint> ) ;
  friend GridPoint midpoint(const GridPoint &p1,
			    const GridPoint &p2) ;
  friend std::ostream &operator<<( std::ostream &out,
				   const GridPoint &g ) {
      out << "<" << g.positionVector[0] << " "
	  << g.positionVector[1] << " "
	  << g.positionVector[2] << ">" ;
    }

  friend bool calculateIntersectionPoint
    (GridPoint g11, GridPoint g12, GridPoint g21, GridPoint g22,
     double &t1, double &t2) ;

 public:
  GridPoint() ;
  ~GridPoint() {}

  double positionVector[3] ;

  GridPoint( const GridPoint &gp );
  GridPoint( const double xx, const double yy,
	     const double zz ) ;
  GridPoint( const double xx, const double yy ) ;

  GridPoint& operator= ( const GridPoint &gp );

  void copy( const GridPoint &gp );
  void print() ;

  // Geometric functions //

  double norm( void ) ;
  void normalize( void ) ;
  GridPoint normalizeGP(void) ;
  double distance( const GridPoint &gp ) ;

  double dot( GridPoint p ) const ;
  GridPoint cross( GridPoint p ) const ;
  double scalarTripleProduct( GridPoint p1, GridPoint p2 ) ;
  double distanceFromLine( const GridPoint &p1,
			   const GridPoint &p2 ) ;
  int inRange( GridPoint p1, GridPoint p2 ) ;
  int isParallel( GridPoint p1, GridPoint p2 ) ;
  int isCoplanar( const GridPoint &p1, const GridPoint &p2,
		  const GridPoint &p3, const GridPoint &p4 ) ;
  bool inBetween2D(GridPoint p1, GridPoint p2) ;
  double getParametricValue(GridPoint start, GridPoint end) ;
 };

const GridPoint KVector(0,0,1) ;
const GridPoint IVector(1,0,0) ;
const GridPoint JVector(0,1,0) ;
const GridPoint ZeroVector(0,0,0) ;

#endif

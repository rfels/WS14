#include "GridPoint.h"

// Public functions //

GridPoint :: GridPoint() {
  for ( int i=0; i < 3 ; i++ )
    positionVector[i] = 0.0 ;
}

GridPoint :: GridPoint( const double xx, const double yy,
			const double zz ) {
  positionVector[0] = xx ; 
  positionVector[1] = yy ;
  positionVector[2] = zz ;
}

GridPoint :: GridPoint( const double xx, const double yy ) {
  positionVector[0] = xx ;
  positionVector[1] = yy ; 
  positionVector[2] = 0.0 ;
}

GridPoint :: GridPoint (const GridPoint &gp) {
  for ( int i = 0 ; i < 3 ; i++ )
    positionVector[i] = gp.positionVector[i] ;
}

GridPoint& GridPoint :: operator= (const GridPoint &gp) {
  if (this == &gp) return (*this);
  else copy(gp);

  return(*this);    
}

void GridPoint :: copy(const GridPoint &gp) {
  for ( int i = 0 ; i < 3 ; i++ )
    positionVector[i] = gp.positionVector[i] ;

  return;
}


void GridPoint :: print() {
  std :: cout << positionVector[0] << "\t" 
	      << positionVector[1] << "\t" 
	      << positionVector[2] << std :: endl ;
  return; 
}

// Geometric functions //

double GridPoint :: norm( void ) {
  return sqrt(dot(*this )) ; 
}

void GridPoint :: normalize( void ) {
  double l_norm = norm() ;
 
  if ( l_norm == 0 ) return ;

  for ( int i = 0 ; i < 3 ; i++ )
    positionVector[i] /= l_norm ;

  return ;
}

GridPoint GridPoint :: normalizeGP(void) {
  normalize() ; return *this ; 
}
  
double GridPoint :: distance( const GridPoint &gp ) {
  return ((*this)-gp).norm() ; 
}



double GridPoint :: dot(GridPoint g1) const { 
  double result = 0.0 ;
  for ( int i = 0 ; i < 3 ; i++ )
    result += g1.positionVector[i] * positionVector[i] ;
  
  return result ;
}

GridPoint GridPoint :: cross(GridPoint g1) const {
  GridPoint g ;

  for ( int i = 0 ; i < 3 ; i++ )
    g.positionVector[i] = positionVector[(i+1)%3]*g1.positionVector[(i+2)%3]-
      positionVector[(i+2)%3]*g1.positionVector[(i+1)%3] ;
  /*
  GridPoint result ;

  result.positionVector[0] = positionVector[1]*p.positionVector[2] -
    positionVector[2]*p.positionVector[1] ;
  result.positionVector[1] = positionVector[2]*p.positionVector[0] -
    positionVector[0]*p.positionVector[2] ;
  result.positionVector[2] = positionVector[0]*p.positionVector[1] -
    positionVector[1]*p.positionVector[0] ;
  */
  return g ;
}

double GridPoint :: scalarTripleProduct( GridPoint p1,
					 GridPoint p2 )
{ return dot( p1.cross(p2) ) ; }

double GridPoint :: distanceFromLine( const GridPoint &p1,
				      const GridPoint &p2 ) {
  if ( ( p1 - p2 ).norm() == 0  )
    return distance(p2) ;
  double result = (((*this)-p1).cross( (*this)-p2)).norm() ;
  result /= (p1-p2).norm()  ;

  return result ;
}

int GridPoint :: inRange( GridPoint p1, GridPoint p2 ) {
  if ( (*this) == p1 || (*this) == p2 ||
       fabs(distance(p1)+distance(p2)-p1.distance(p2)) < 1e-5) 
    return 1 ;
  
  return 0 ;
}

int GridPoint :: isParallel( GridPoint p1, GridPoint p2 ) {
  /*
  GridPoint diff1, diff2, _cross ;
  for ( int i = 0 ; i < 3 ; i++)
    {
      diff1.positionVector[i] = ( positionVector[i] - p2.positionVector[i] ) ;
      diff2.positionVector[i] = ( p1.positionVector[i] - p2.positionVector[i] ) ;
    }
  
  if ( (diff1.cross(diff2)).norm() == 0 ) return 1 ;
  else return 0 ; 
  */

  GridPoint diff1 = p1-*this ;
  GridPoint diff2 = p2-p1 ;
  double ang1 = atan2(diff1.positionVector[1], diff1.positionVector[0]) ;
  double ang2 = atan2(diff2.positionVector[1], diff2.positionVector[0]) ;
  double angdiff = fabs(ang1-ang2) ;

  if (angdiff < 1e-5 || fabs(M_PI-angdiff) < 1e-5) return 1 ;
  else return 0 ;
}

int GridPoint :: isCoplanar( const GridPoint &p1, const GridPoint &p2,
			     const GridPoint &p3, const GridPoint &p4 ) {
  /* GridPoint _cross1 = ((*this) - p1).cross((*this) - p2) ;
  GridPoint _cross2 = ((*this) - p2).cross((*this) - p3) ;
  GridPoint _cross3 = ((*this) - p3).cross((*this) - p4) ;
  GridPoint _cross4 = ((*this) - p4).cross((*this) - p1) ;

  double _length1 = ( p1 - p2 ).norm() ;
  double _length2 = ( p1 - p4 ).norm() ;
  double _area_sum = 0.5 * ( _cross1.norm() + _cross2.norm() + 
			     _cross3.norm() + _cross4.norm() ) ;

  if ( _area_sum != _length1*_length2 ) return 0 ;
  else return 1 ;*/

  GridPoint cross1 = ((*this)-p1).cross((*this)-p2) ;
  GridPoint p3_0 = p3 ; 
  GridPoint p4_0 = p4 ;
  if ((p3_0.dot(cross1) == 0) && (p4_0.dot(cross1) == 0)) 
    return 1 ;
  else return 0 ;
}

bool GridPoint :: inBetween2D(GridPoint p1, GridPoint p2) {
  GridPoint normal = GridPoint(0,0,1).cross((p2-p1).normalizeGP()) ;
  GridPoint projectedpt = *this-(normal.dot(*this-p1))*normal ;
  int found = 0, index = 0 ;
  while (!found && index < 3)
    if (p1.positionVector[index] != p2.positionVector[index])
      found = 1 ;
    else index++ ;

  if (found) {
    double ratio = (projectedpt.positionVector[index]-
		    p1.positionVector[index])/
      (p2.positionVector[index]-p1.positionVector[index]) ;
    if (ratio >= 0.0 && ratio <= 1.0) return true ;
  }

  return false ;
}

double GridPoint :: getParametricValue(GridPoint start, GridPoint end) {
  if (!inRange(start, end)) return -1 ;

  double *r[3] = {NULL, NULL, NULL} ;
  for (int i = 0 ; i < 3 ; i++) {
    double den = end.positionVector[i] - start.positionVector[i] ;
    if (den) 
      r[i] = new double((positionVector[i]- start.positionVector[i])/den) ;
  }

  for (int i = 0 ; i < 2 ; i++)
    for (int j = i+1 ; j < 3 ; j++)
      if (r[i] && r[j] && *r[i] != *r[j]) 
	return -1 ;

  for (int i = 0 ; i < 3 ; i++)
    if (r[i]) return *r[i] ;

  if (*this == start) return 1 ;
  else return -1 ;
      
}

// Friend functions //

GridPoint operator+( const GridPoint &g1, 
		     const GridPoint &g2 ) {
  GridPoint g ;
  
  for ( int i = 0 ; i < 3 ; i++ )
    g.positionVector[i]=g1.positionVector[i]+g2.positionVector[i] ;
  return g ;
}

GridPoint operator-( const GridPoint &g1, 
		     const GridPoint &g2 ) {
  GridPoint g ;

  for ( int i = 0 ; i < 3 ; i++ )
    g.positionVector[i] = g1.positionVector[i]-g2.positionVector[i];
  return g ;
}

GridPoint operator*( const GridPoint &g1, 
		     const double &g2 ) {
  GridPoint g ;

  for ( int i = 0 ; i < 3 ; i++ )
    g.positionVector[i] = g2*g1.positionVector[i] ;
  return g ;
}

GridPoint operator*( const double &g2, 
		     const GridPoint &g1 ) {
  return ( g1*g2 ) ;
}

GridPoint operator/( const GridPoint &g1, 
		     const double &g2 ) {
  if ( g2 == 0.0 )
    return g1 ;
  else
    return ( g1*(1.0/g2) ) ;
}

int operator== (const GridPoint &g1, const GridPoint &g2)  {
  for ( int i = 0 ; i < 3 ; i++ )
    if (fabs(g1.positionVector[i]-g2.positionVector[i]) > 1e-4)
      return 0;
  return 1;
}

int operator!= (const GridPoint &g1, const GridPoint &g2) {
  for ( int i = 0 ; i < 3 ; i++ )
    if (fabs(g1.positionVector[i]-g2.positionVector[i])>1e-4)
      return 1;
  return 0;
}


GridPoint midpoint( const GridPoint &p1,
		    const GridPoint &p2 ) {
  GridPoint mid ;

  for ( int i = 0 ; i < 3 ; i++ )
    mid.positionVector[i] = 0.5*(p1.positionVector[i] + 
				 p2.positionVector[i] ) ;
  
  return( mid ) ;
}

GridPoint average( const std :: vector<GridPoint> g_vec )  {
  if ( g_vec.empty() ) 
    return ( GridPoint( 0.0 , 0.0 , 0.0 ) ) ;

  GridPoint g = g_vec[0];
  for ( int i = 1 ; i < 3 ; i++ )
    g = g + g_vec[i] ;

  g = g/g_vec.size() ;

  for ( int i = 0 ; i < 3 ; i++ )
    if ( fabs(g.positionVector[i]) < 1e-2 )
      g.positionVector[i] = 0 ; 
  return g ;
}



bool calculateIntersectionPoint(GridPoint g11, GridPoint g12, 
				GridPoint g21, GridPoint g22,
				double &t1, double &t2) {
  t1 = -1 ; t2 = -1 ;
  GridPoint del1 = g12-g11 ;
  GridPoint del2 = g22-g21 ;
  GridPoint del3 = g21-g11 ;

  double den[] = {del2.positionVector[1]*del1.positionVector[0]-
		  del2.positionVector[0]*del1.positionVector[1],
		  
		  del2.positionVector[2]*del1.positionVector[1]-
		  del2.positionVector[1]*del1.positionVector[2],
		  
		  del2.positionVector[0]*del1.positionVector[2]-
		  del2.positionVector[2]*del1.positionVector[0]} ;
		  
  double s1[] = {(del3.positionVector[0]*del2.positionVector[1]-
		  del3.positionVector[1]*del2.positionVector[0])/den[0],
		 
		 (del3.positionVector[1]*del2.positionVector[2]-
		  del3.positionVector[2]*del2.positionVector[1])/den[1],
		 
		 (del3.positionVector[2]*del2.positionVector[0]-
		  del3.positionVector[0]*del2.positionVector[2])/den[2]} ;

  double s2[] = {(del3.positionVector[0]*del1.positionVector[1]-
		  del3.positionVector[1]*del1.positionVector[0])/den[0],
		 
		 (del3.positionVector[1]*del1.positionVector[2]-
		  del3.positionVector[2]*del1.positionVector[1])/den[1],
		 
		 (del3.positionVector[2]*del1.positionVector[0]-
		  del3.positionVector[0]*del1.positionVector[2])/den[2]} ;

  for (int i = 0 ; i < 3 ; i++) 
    if (fabs(s1[i]) <= 1e-10) s1[i] = 0.0 ;
  for (int i = 0 ; i < 3 ; i++) 
    if (fabs(s2[i]) < 1e-10) s2[i] = 0.0 ;

  int found  = 0 ; int ii = 0 ;
  while (!found && ii < 3)
    if (fabs(den[ii]) > 1e-10) { //-3)
      t1 = s1[ii] ; t2 = s2[ii] ;
      found = 1 ; return true ;
    } else ii++ ;

  return false ;
}

